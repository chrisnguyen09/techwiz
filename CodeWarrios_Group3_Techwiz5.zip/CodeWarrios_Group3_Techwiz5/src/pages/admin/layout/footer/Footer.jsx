import React from 'react';

const Footer = () => {
    return (
        <div>
            footerc
        </div>
    );
};

export default Footer;